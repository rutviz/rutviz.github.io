/* just to see boxes in "dev mode" */
$('.dev').on('click', function(){
  $('.part').toggleClass('devmode');
  return false;
});