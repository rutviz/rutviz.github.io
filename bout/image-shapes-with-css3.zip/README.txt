A Pen created at CodePen.io. You can find this one at http://codepen.io/CreativeJuiz/pen/Hizkh.

 Some image shapes realized with overflow hidden and tranform-rotate property.